
import React from 'react';
// import {useState, useEffect} from 'react';
// import ReactPlayer from 'react-player'; // ReactPlayer import 추가
import './css/main.css';


function Main( {userInfo} ) {
  return (

    <>
      <h2>{userInfo}</h2>
    </>
  );
}

export default Main;