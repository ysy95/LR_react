import React from 'react';

function ErrorPage(props) {
  return (
    <div>
      404
    </div>
  );
}

export default ErrorPage;