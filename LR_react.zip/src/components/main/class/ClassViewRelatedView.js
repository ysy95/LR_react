import React from 'react';

function ClassViewRelatedView(props) {
  return (
    <div>
    {/* php  */}
    <iframe width="175" height="105" src="https://www.youtube.com/embed/dvTiIN-emBg" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
    <p>강재민의 강냉이 털기</p>
    </div>
  );
}

export default ClassViewRelatedView;